import { Component } from '@angular/core';

@Component({
  selector: 'app-component-navbar',
  imports: [],
  templateUrl: './component-navbar.html',
  styleUrl: './component-navbar.css',
})
export class ComponentNavbar {

}
