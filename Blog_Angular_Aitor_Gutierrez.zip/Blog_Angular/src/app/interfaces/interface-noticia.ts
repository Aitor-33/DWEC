export interface InterfaceNoticia {
titulo: string;
imagen: string;
cuerpoNoticia:string;
fechaNoticia: Date;

}
