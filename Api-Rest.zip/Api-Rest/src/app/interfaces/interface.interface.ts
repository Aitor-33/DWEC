import { InterfaceUsuario } from "./interface-usuario.interface";

export interface Interface {

    page:number;
    per_page:number;
    total_pages:number;
    results:InterfaceUsuario[];



}
