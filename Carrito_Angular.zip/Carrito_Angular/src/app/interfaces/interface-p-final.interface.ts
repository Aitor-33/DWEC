import { InterfaceProducto } from "./interface-producto.interface"
export interface InterfacePFinal {

  producto: InterfaceProducto;
  cantidad: number;

}
