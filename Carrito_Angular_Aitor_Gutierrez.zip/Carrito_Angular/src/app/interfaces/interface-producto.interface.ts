export interface InterfaceProducto {

    sku: string,
    title: string,
    price: string,

}
